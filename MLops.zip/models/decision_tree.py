from sklearn.tree import DecisionTreeClassifier

import typer
from src.params.pipe_params import read_pipeline_params
import pickle
from loguru import logger

app = typer.Typer()


@app.command()
def main(params_path: str):
    params = read_pipeline_params(params_path)
    tree = DecisionTreeClassifier(max_depth=params.train_params.n_estimators)

    with open(params.train_params.model_path, 'wb') as model_file:
        pickle.dump(tree, model_file)
    logger.info(f"Tree created in {params.train_params.model_path}")
'''
tree = DecisionTreeClassifier(max_depth=5)
tree.fit(X_train, y_train)
y_pred_tree = tree.predict(X_test)

print("Accuracy:", accuracy_score(y_test, y_pred_tree))
print(classification_report(y_test, y_pred_tree))
'''

if __name__ == "__main__":
    app()
